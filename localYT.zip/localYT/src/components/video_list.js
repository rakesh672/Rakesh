import React, { Component } from 'react';
import VideoListItem from './video_list_item';

class VideoList extends Component {
    render() {
        return (
            <div className="col-md-4">
                <ul className="list-group">
                    {this.props.videos.map((video, index) => (
                        <VideoListItem key={video.etag} isSelected={this.props.selectedVideo} video={video} />
                    ))}
                </ul>
            </div>
        )
    }
}

export default VideoList;