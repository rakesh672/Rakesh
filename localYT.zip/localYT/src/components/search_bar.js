import React, { Component } from 'react';

class SearchBar extends Component {
    constructor(props) {
        super(props);
        this.state = { term: '' }
    }
    onInputChange = (term) => {
        this.setState({ term: term });
        this.props.onSearchTermChange(term);
    }
    render() {
        return (
            <div>

                <div className="main">
                    <div className="input-group">
                        <input type="text" className="form-control" placeholder="Search.." name="search" value={this.props.value} onChange={event => this.onInputChange(event.target.value)} />
                        <div className="input-group-append">
                            <button className="btn btn-secondary" type="button">
                                <i className="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default SearchBar;
