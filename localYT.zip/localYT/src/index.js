 import React from 'react';
 import ReactDOM from 'react-dom';
 import App from './App';
 //create a new component. This component should produce the HTML
 

 ReactDOM.render(<App />, document.querySelector(".container"));