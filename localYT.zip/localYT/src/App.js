import _ from 'lodash';
import React, { Component } from 'react';
import YTSearch from 'youtube-api-search';
import Searchbar from './components/search_bar';
import VideoList from './components/video_list';
import VideoDetail from './components/video_detail';


const API_KEY = 'AIzaSyCrdxhAMbsLgjJa-uBfr7Di-dog5vWomFw';



class App extends Component {
    constructor(props) {
        super(props);
        this.state = { videos: [], selectedVideo: null }

        this.onVideoSearch("neha kakkar");

    }

    onVideoSearch = (term) => {
        YTSearch({ key: API_KEY, term: term }, (data) => {
            this.setState(
                {
                    videos: data,
                    selectedVideo: data[0]
                });
        })
    }
    onSelectVideo = (video) => {
        this.setState({ selectedVideo: video })
    }

    render() {

        const videoSearch=_.debounce((term)=>{this.onVideoSearch(term)},3000);
        return (
            <div>
                <Searchbar onSearchTermChange={videoSearch}  />
                <div className="row">
                    <VideoDetail video={this.state.selectedVideo} />
                    <VideoList selectedVideo={this.onSelectVideo} videos={this.state.videos} />
                </div>
            </div>
        )
    }
}

export default App;